# Windows PowerShell version of get_sounds.sh
# Downloads a few 5-second clips per category from ESC-50 into .\audio
# Run:  powershell -ExecutionPolicy Bypass -File get_sounds.ps1
$ErrorActionPreference = "Stop"
$PerCategory = 3
$Base = "https://raw.githubusercontent.com/karolpiczak/ESC-50/master"
$Categories = "chainsaw","engine","hand_saw","crickets","chirping_birds","rain","insects"

New-Item -ItemType Directory -Force -Path audio | Out-Null
$meta = (Invoke-WebRequest -UseBasicParsing "$Base/meta/esc50.csv").Content -split "`n"

foreach ($cat in $Categories) {
  $files = $meta | Where-Object { $_ -match ",$cat," } | Select-Object -First $PerCategory
  $i = 1
  foreach ($line in $files) {
    $f = ($line -split ",")[0]
    $out = "audio\${cat}_$i.wav"
    Invoke-WebRequest -UseBasicParsing -OutFile $out "$Base/audio/$f"
    Write-Host "saved $out  (source: $f)"
    $i++
  }
}
Write-Host "Done. Elephant sounds are not in ESC-50 - see the guide for elephant sources."
