#!/usr/bin/env bash
# Downloads a few 5-second clips per category from the ESC-50 dataset
# (https://github.com/karolpiczak/ESC-50, CC BY-NC 3.0) into ./audio
# Run in Cloud Shell, macOS Terminal, or Git Bash on Windows:
#   bash get_sounds.sh
set -euo pipefail

PER_CATEGORY=3
BASE="https://raw.githubusercontent.com/karolpiczak/ESC-50/master"
CATEGORIES="chainsaw engine hand_saw crickets chirping_birds rain insects"

mkdir -p audio
curl -sSL -o audio/esc50.csv "$BASE/meta/esc50.csv"

for cat in $CATEGORIES; do
  i=1
  for f in $(grep ",$cat," audio/esc50.csv | head -n "$PER_CATEGORY" | cut -d, -f1); do
    out="audio/${cat}_${i}.wav"
    curl -sSL -o "$out" "$BASE/audio/$f"
    echo "saved $out  (source: $f)"
    i=$((i + 1))
  done
done

rm audio/esc50.csv
echo "Done. Elephant sounds are not in ESC-50 - see the guide for elephant sources."
